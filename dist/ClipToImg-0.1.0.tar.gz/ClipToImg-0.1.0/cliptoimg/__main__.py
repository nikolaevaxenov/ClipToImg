from cliptoimg.cliptoimg import ClipToImg


def main():
    ClipToImg.start()


if __name__ == '__main__':
    main()
